import React from 'react';
import './index.css';
// import bg from 'src/Background.jpeg'


function About() {
  return (
    <div className="about-container">
      <h1>About Us</h1>
      <p>Find your favorite food anytime, anywhere at FoodPilot</p>
    </div>
  );
}

export default About;